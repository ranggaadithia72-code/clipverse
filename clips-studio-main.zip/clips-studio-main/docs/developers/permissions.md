# Permissions

A plugin lists what it needs in its manifest's `permissions`, `network` and `sends`. The user sees each one, in plain words, before installing. This page says, for each, whether Clips Kitty **enforces** it (checks it and refuses otherwise) or whether it is **declared** (the developer states it and nothing stops the plugin doing otherwise). The install screen shows enforced as "Clips Kitty hands this over" and declared as "the developer says so", and explains them: "“Clips Kitty hands this over”: Clips Kitty decides what the pipeline is given. “The developer says so”: a promise only. Nothing stops a pipeline doing more, because it can do anything you can do on this PC." (`plugins/permissions.py`).

**The rule behind the table.** A plugin is a program that runs on the user's PC with the user's own rights, as any program they install does. Clips Kitty decides what it *hands over* to a plugin, so a permission can be enforced for what is handed over. Clips Kitty does not sandbox the plugin's process, so it cannot stop a plugin from opening files, starting programs or using the network on its own. Where this page says "declared", that is why.

| Permission | Shown to the user as | Enforced or declared | Status |
|---|---|---|---|
| `video.read` | Reads the video you process | **Enforced** for the hand-over: without it the job has no video path. Declared beyond that. | built |
| `transcript.read` | Reads its transcript | **Enforced** for the hand-over: without it no transcript is written, and the moments a rater or understander is handed come without their `title`, `reason` and `context`, which come from what was said. Declared beyond that. | built |
| `ffmpeg` | Uses Clips Kitty's FFmpeg | **Enforced** for the hand-over: without it the job has no FFmpeg path. Declared beyond that. | built |
| `ollama` | Uses your local AI model | **Enforced** for the hand-over: without it the job has no Ollama address. A cloud AI provider's name and key are never handed over. Declared beyond that: Ollama has no password, so any program on the PC can use it. | built |
| `twitch.context.read` | Reads permitted Twitch stream and VOD information | **Enforced** by the account gateway for the bound account and broadcaster: that channel's VOD list (up to 100 per request) and live status (title, game, viewer count), and links into this run's VOD. No OAuth tokens are handed over. Same-user OS access remains outside this gate. | built |
| `twitch.clips.create` | Asks Clips Kitty to create Twitch Clips when authorized | **Enforced** for host requests and OAuth scopes: a 5–60-second clip of this run's VOD, which needs `channel:manage:clips` or `editor:manage:clips` and a verified timeline (today: the run's file is the whole Twitch archive, as Watched channels downloads it). A run never clips the live broadcast. | built |
| `twitch.chat.read` | Reads permitted Twitch chat messages | **Enforced** for host events, with `twitch.events.read` (the manifest check refuses it without) and Twitch's read-chat scope. | built |
| `twitch.chat.send` | Sends messages to the permitted Twitch channel | **Enforced** for host sends, the bound broadcaster, authorized sender and Twitch's write-chat scope. | built |
| `twitch.events.read` | Receives permitted Twitch stream events | **Enforced** for host-owned subscriptions and bounded, sanitized event reads. | built |
| `gpu` | Uses your graphics card | Declared (a requirement, compared with this PC) | built (shown with the plugin manager) |
| `network` with the `network` hosts | Connects to: api.example.com, … | Declared. Clips Kitty does not filter a plugin's connections. | built (validated; shown with the plugin manager) |
| `sends` | ⚠ Sends your video / audio / frames / transcript to … | Declared, and shown as a warning wherever the plugin is listed or installed | built (validated; shown with the plugin manager and Marketplace) |
| `filesystem.read`, `filesystem.write` | Reads / writes files outside its own folder | Declared | built (validated) |
| `project.read`, `project.write` | Reads / changes your clip library | Declared: the local API has no authentication, so any program on the PC can call it | built (validated) |
| `models` (the manifest's `models:` list) | Uses these models: … | Enforced for downloads Clips Kitty makes (only the listed files, checked against their size and SHA-256, and only when the user presses Download); declared beyond, since the plugin's own code can fetch anything | built ([Model references](model-references.md)) |
| `clips.write` | Returns finished clips | Refused in plugin contract 1 | planned |

The manifest validator also ties them together: an `inputs` entry needs its permission (`video` needs `video.read`), hosts in `network` need the `network` permission and the other way round, and a `remote` or `hybrid` pipeline must list both `network` and `sends`. A `local` pipeline may not list `sends`. The `moments` input needs no permission: it holds the moments' times, scores, labels and Clips Kitty's own signal scores, and what was said reaches a plugin only with `transcript.read`.

A moment's `title`, `reason` and `context` are taken from the transcript, so sending them off the PC counts as sending the transcript: a plugin that does so lists `transcript` in `sends`, as it would for the transcript itself. Like every `sends` entry, that is declared: Clips Kitty shows it to the user but can't check it ([Steps](steps.md)).

**Suggesting edits needs no permission.** An edit run hands over the clips as moments, and what earlier edit plugins suggested for them (`suggested`); their reasons and hook titles are plugin text that may come from what was said, so they reach a plugin only with `transcript.read`. What Clips Kitty does with the answer is the same for every plugin:

> Clips Kitty doesn’t put a suggestion into a clip until you use it in the editor and apply your edits (Apply edits, or Apply edits & upload).

That sentence says what Clips Kitty does with a suggestion, not what a plugin is able to do. A plugin runs as the user, so nothing stops its own code from changing clip files or posting by itself, as with any program the user installs; that is why `filesystem.write` and `project.write` are declared, not enforced ([Steps](steps.md#suggest-edits-the-edit-step)).

## Also enforced, whatever the permissions

- **The environment.** A plugin's process does not inherit Clips Kitty's own variables (`CLIPS_*`, `CLIPSKITTY_*`) or any variable whose name contains KEY, TOKEN, SECRET, PASSWORD, PASSWD, CREDENTIAL, COOKIE or AUTH. This stops Clips Kitty handing over credentials by accident; it is not a wall, since the plugin can read the user's files.
- **Secrets.** A plugin's `secret` settings reach only its own process, only in its environment, never in a file. They are not isolated from other software: the store is encrypted for the user's account (Windows) or readable only by the user (elsewhere), so another plugin running as the user can read it.
- **Connected account operations.** A dedicated, expiring capability is explicitly passed to an authorized run after inherited credentials are removed. The host binds it to installed permissions, account, broadcaster and verified source VOD; it is revoked on exit or disconnection. Provider tokens are never passed. See [Connected Accounts SDK](connected-accounts-sdk.md).
- **Settings.** Only settings the manifest declares, with values that fit their type.
- **Time.** A run stops at `run.timeout_minutes`: by default 60 minutes for a run that finds moments and 10 for one that rates or understands them or suggests edits for the clips. A cancelled job stops the plugin and everything it started.
- **Installing runs nothing** from the plugin (built with the plugin manager).

## Not enforced, and said so

- No sandbox: file, process and network access are the user's.
- No resource limits on memory or child processes. Windows Job Object limits are designed and will be called enforced only once built and tested on Windows.
- The general local API remains open to programs on the PC. Connected Accounts has scoped per-run credentials and a session-protected desktop API, but same-user native programs can attempt to read the desktop session file or user-protected resources outside the SDK. This is not an OS sandbox.

## Tiers and labels grant nothing

A plugin's install tier ("✓ Official · made by the Clips Kitty project", "Community · not reviewed by a person", "Not listed · Clips Kitty has not checked this") and its Marketplace labels (✓ Official, ✓ Compatible, ★ Featured) change nothing in the tables above: every plugin is handed what its permissions allow, and the same things stay declared. ✓ Compatible means one version's manifest is valid, it installs, its requirements are met and it runs on a sample video with an answer Clips Kitty accepts; it does not check that the plugin keeps to its declared `network`, `sends` or file permissions.

Clips Kitty's own install counter is not a plugin permission and sends nothing about the user or their videos; [Security](security.md#what-clips-kitty-sends-when-you-install) says what it sends and how to switch it off.

See [Security](security.md) for what this means for people installing plugins.
